const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const peso=n=>'₱'+Number(n).toLocaleString('en-PH',{minimumFractionDigits:2,maximumFractionDigits:2});
const tok=()=>localStorage.getItem('cm_token');
async function api(p,o={}){
  const r=await fetch('/api'+p,{method:o.method||(o.body?'POST':'GET'),headers:{'Content-Type':'application/json',...(tok()?{Authorization:'Bearer '+tok()}:{})},body:o.body?JSON.stringify(o.body):undefined});
  const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||'Request failed');return j;
}
const tbl=(h,rows)=>rows.length?`<div class=tw><table><tr>${h.map(x=>`<th>${x}</th>`).join('')}</tr>${rows.map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join('')}</tr>`).join('')}</table></div>`:'<p>Nothing here yet.</p>';
function openModal(h){closeModal();document.body.insertAdjacentHTML('beforeend',`<div id=ov class=ov><div class=md>${h}<p style="margin-top:12px"><button class=btn2 onclick=closeModal()>Close</button></p></div></div>`)}
function closeModal(){$('#ov')?.remove()}
function receiptHTML(o){return `<div class=rc><h3 style="text-align:center">☕ Cassey Manwa Coffee</h3><p style="text-align:center">Official Receipt</p><hr><p>Order: ${esc(o.order_no)}<br>${new Date(o.paid_at||o.created_at).toLocaleString('en-PH')}<br>${esc(o.type)} · ${esc(o.customer_name)}</p><hr>${o.items.map(i=>`<div class=rl><span>${i.qty}× ${esc(i.name)}</span><span>${peso(i.qty*i.price)}</span></div>`).join('')}<hr><div class=rl><b>TOTAL</b><b>${peso(o.total)}</b></div><p>Paid via ${o.payment_method==='cash'?'Cash':'QR Ph (PayMongo)'}</p><p style="text-align:center">Thank you!</p></div>`}
function showReceipt(o){if(!$('#rcpt'))document.body.insertAdjacentHTML('beforeend','<div id=rcpt></div>');$('#rcpt').innerHTML=receiptHTML(o);openModal(`<div class=left>${receiptHTML(o)}</div><p><button class=btn onclick="window.print()">🖨 Print receipt</button></p>`)}
async function rcpt(no){try{showReceipt(await api('/orders/track/'+no))}catch(e){alert(e.message)}}
/* Shows a dynamic QR Ph for the exact order total, then polls until PayMongo confirms payment. No simulated confirmation. */
async function showQR(no,done){
  openModal('<div id=qb>Generating QR Ph…</div>');
  try{const q=await api(`/orders/${no}/qr`,{method:'POST',body:{}});
    $('#qb').innerHTML=`<h3>Scan to pay</h3><img class=qr alt="QR Ph" src="${esc(q.image)}"><p class=big>${peso(q.total)}</p><p>Order <b>${esc(no)}</b><br>Pay with GCash, Maya or any QR Ph bank app. Do not close this window until it confirms.</p><p id=ps>⏳ Waiting for payment…</p>`;
    const t=setInterval(async()=>{if(!$('#qb')){clearInterval(t);return}
      const o=await api('/orders/track/'+no).catch(()=>null);
      if(o?.payment_status==='paid'){clearInterval(t);closeModal();done(o)}},4000);
  }catch(e){const b=$('#qb');if(b)b.innerHTML='<p class=err>'+esc(e.message)+'</p>'}
}
