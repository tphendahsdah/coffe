let MENU={categories:[],products:[]},cat=0,cart=JSON.parse(localStorage.getItem('cm_cart')||'{}'),tt=null;
const save=()=>{localStorage.setItem('cm_cart',JSON.stringify(cart));drawCart()};
const prod=id=>MENU.products.find(p=>p.id==id);
async function init(){MENU=await api('/menu');drawMenu();drawCart();acctLabel();const l=localStorage.getItem('cm_last');if(l){$('#tn').value=l;track()}}
function drawMenu(){
  $('#chips').innerHTML=`<button class="${cat?'':'on'}" onclick="cat=0;drawMenu()">All</button>`+MENU.categories.map(c=>`<button class="${cat==c.id?'on':''}" onclick="cat=${c.id};drawMenu()">${esc(c.name)}</button>`).join('');
  $('#grid').innerHTML=MENU.products.filter(p=>!cat||p.category_id==cat).map(p=>`<div class="card item">${p.image_url?`<img loading=lazy alt="" src="${esc(p.image_url)}">`:'<div class=ph>☕</div>'}<h3>${esc(p.name)}</h3><small>${esc(p.description)}</small><div class=row><span class=price>${peso(p.price)}</span><button class=btn ${p.stock<1?'disabled':''} onclick="add(${p.id})">${p.stock<1?'Sold out':'Add'}</button></div></div>`).join('')||'<p>No items.</p>';
}
function add(id){const p=prod(id);if((cart[id]||0)>=Math.min(p.stock,20))return;cart[id]=(cart[id]||0)+1;save();$('#cart').classList.add('open')}
function chg(id,d){cart[id]=(cart[id]||0)+d;if(cart[id]<=0)delete cart[id];else if(cart[id]>Math.min(prod(id).stock,20))cart[id]--;save()}
function drawCart(){
  for(const id of Object.keys(cart))if(!prod(id)&&MENU.products.length)delete cart[id];
  const ids=Object.keys(cart).filter(prod);let t=0;
  $('#cc').textContent=ids.reduce((s,i)=>s+cart[i],0);
  $('#ci').innerHTML=ids.map(i=>{const p=prod(i);t+=p.price*cart[i];return `<div class=li><span>${esc(p.name)}</span><span><button onclick="chg(${i},-1)">−</button> ${cart[i]} <button onclick="chg(${i},1)">+</button></span><span>${peso(p.price*cart[i])}</span></div>`}).join('')||'<p>Your cart is empty.</p>';
  const me=JSON.parse(localStorage.getItem('cm_me')||'null');
  $('#cf').innerHTML=ids.length?`<h3>Total ${peso(t)}</h3><input id=cn placeholder="Your name" value="${esc(me?.name||'')}"><select id=ct><option value=takeout>Takeout</option><option value=dine-in>Dine-in</option></select><button class=btn style="width:100%;margin-top:6px" onclick=checkout()>Pay with QR Ph</button><p id=ce class=err></p>`:'';
}
async function checkout(){
  try{const name=$('#cn').value.trim();if(!name)throw new Error('Please enter your name');
    const o=await api('/orders',{body:{name,type:$('#ct').value,items:Object.entries(cart).map(([id,qty])=>({id:+id,qty}))}});
    localStorage.setItem('cm_last',o.orderNo);$('#cart').classList.remove('open');
    showQR(o.orderNo,p=>{cart={};save();showReceipt(p);$('#tn').value=o.orderNo;track()});
  }catch(e){$('#ce').textContent=e.message}
}
async function track(){
  clearInterval(tt);const no=$('#tn').value.trim().toUpperCase();if(!no)return;
  const draw=async()=>{try{const o=await api('/orders/track/'+encodeURIComponent(no));localStorage.setItem('cm_last',no);
    const st=['pending','preparing','ready','completed'],i=st.indexOf(o.status);
    $('#tr').innerHTML=o.status==='cancelled'?'<p class=err>This order was cancelled.</p>':`<h3>${esc(o.order_no)} · ${peso(o.total)}</h3><div class=steps><span class="${o.payment_status==='paid'?'on':''}">Paid</span>${['Received','Preparing','Ready','Completed'].map((s,k)=>`<span class="${o.payment_status==='paid'&&k>0&&i>=k-0||(k==0&&o.payment_status==='paid')?'on':''}">${s}</span>`).join('')}</div>`+
      (o.payment_status==='paid'?`<button class=btn2 onclick="rcpt('${esc(no)}')">View receipt</button>`:`<p>Awaiting payment.</p><button class=btn onclick="showQR('${esc(no)}',p=>{showReceipt(p);track()})">Pay now</button>`);
  }catch(e){$('#tr').innerHTML='<p class=err>'+esc(e.message)+'</p>';clearInterval(tt)}};
  await draw();tt=setInterval(draw,8000);
}
/* account */
function acctLabel(){const me=JSON.parse(localStorage.getItem('cm_me')||'null');$('#acct').textContent=me?'👤 '+me.name:'Sign in';if(me&&tok())myOrders()}
async function myOrders(){try{const o=await api('/my/orders');$('#mine').innerHTML='<h3>My orders</h3>'+tbl(['Order','Total','Payment','Status'],o.map(x=>[`<a href="#track" onclick="$('#tn').value='${esc(x.order_no)}';track()">${esc(x.order_no)}</a>`,peso(x.total),x.payment_status,x.status]))}catch{}}
function account(){
  const me=JSON.parse(localStorage.getItem('cm_me')||'null');
  if(me)return openModal(`<h3>${esc(me.name)}</h3><p>${esc(me.role)}</p><button class=btn onclick="localStorage.removeItem('cm_token');localStorage.removeItem('cm_me');location.reload()">Sign out</button>`);
  openModal(`<h3>Account</h3><form class=left onsubmit="return false"><input id=an placeholder="Name (for new account)"><input id=ae type=email placeholder=Email><input id=ap type=password placeholder="Password (8+ chars)"><button class=btn onclick="auth2('login')">Sign in</button> <button class=btn2 onclick="auth2('register')">Create account</button><p id=ar class=err></p></form>`);
}
async function auth2(m){
  try{if(m==='register')await api('/auth/register',{body:{name:$('#an').value,email:$('#ae').value,password:$('#ap').value}});
    const r=await api('/auth/login',{body:{email:$('#ae').value,password:$('#ap').value}});
    localStorage.setItem('cm_token',r.token);localStorage.setItem('cm_me',JSON.stringify(r.user));location.reload();
  }catch(e){$('#ar').textContent=e.message}
}
init();
