let me=null,tab='',MENU=null,cart={},kt=null,CATS=[],PRODS=[],RPT=null;
const TABS={pos:['🧾','POS',['cashier','admin']],kitchen:['👨‍🍳','Kitchen',['kitchen','cashier','admin']],orders:['📋','Orders',['cashier','admin']],products:['☕','Products',['admin']],stock:['📦','Inventory',['admin']],users:['👥','Users',['admin']],reports:['📈','Reports',['admin']]};
function boot(){try{me=JSON.parse(localStorage.getItem('cm_me'))}catch{}me&&tok()&&me.role!=='customer'?show():loginView()}
function loginView(){$('#app').innerHTML=`<div class=login><h2>☕ Cassey Manwa Coffee</h2><p>Staff portal</p><input id=em type=email placeholder=Email><input id=pw type=password placeholder=Password onkeydown="if(event.key==='Enter')doLogin()"><button class=btn style="width:100%;margin-top:8px" onclick=doLogin()>Sign in</button><p id=er class=err></p></div>`}
async function doLogin(){try{const r=await api('/auth/login',{body:{email:$('#em').value,password:$('#pw').value}});if(r.user.role==='customer')throw new Error('Staff accounts only');localStorage.setItem('cm_token',r.token);localStorage.setItem('cm_me',JSON.stringify(r.user));me=r.user;show()}catch(e){$('#er').textContent=e.message}}
function logout(){localStorage.removeItem('cm_token');localStorage.removeItem('cm_me');clearInterval(kt);loginView()}
function show(){const t=Object.entries(TABS).filter(([k,v])=>v[2].includes(me.role));
  $('#app').innerHTML=`<header class=top><b>☕ Cassey Manwa Coffee · ${esc(me.role)}</b><nav>${t.map(([k,v])=>`<button id=t_${k} onclick="go('${k}')">${v[0]} ${v[1]}</button>`).join('')}</nav><button class=btn2 onclick=logout()>Sign out (${esc(me.name)})</button></header><main id=v></main>`;go(t[0][0])}
async function go(t){tab=t;clearInterval(kt);document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('on',b.id==='t_'+t));$('#v').innerHTML='Loading…';
  try{await V[t]()}catch(e){if(/sign in/i.test(e.message))return logout();$('#v').innerHTML='<p class=err>'+esc(e.message)+'</p>'}}
const V={};

/* POS */
V.pos=async()=>{MENU=await api('/menu');drawPos()};
function drawPos(cat=0){
  const nm=$('#cn')?.value||'',ty=$('#ct')?.value||'dine-in';
  const ps=MENU.products.filter(p=>!cat||p.category_id==cat),ids=Object.keys(cart),pr=i=>MENU.products.find(p=>p.id==i);
  const tot=ids.reduce((s,i)=>s+cart[i]*pr(i).price,0);
  $('#v').innerHTML=`<div class=posg><div><div class=chips><button onclick="drawPos(0)">All</button>${MENU.categories.map(c=>`<button onclick="drawPos(${c.id})">${esc(c.name)}</button>`).join('')}</div>
  <div class=grid>${ps.map(p=>`<button class=pc ${p.stock<1?'disabled':''} onclick="padd(${p.id},${cat})"><b>${esc(p.name)}</b><span class=price>${peso(p.price)}</span><small>${p.stock} left</small></button>`).join('')}</div></div>
  <aside class=card><h3>Current order</h3>${ids.map(i=>`<div class=li><span>${esc(pr(i).name)}</span><span><button onclick="padd(${i},${cat},-1)">−</button> ${cart[i]} <button onclick="padd(${i},${cat},1)">+</button> <button onclick="padd(${i},${cat},-99)">✕</button></span><span>${peso(cart[i]*pr(i).price)}</span></div>`).join('')||'<p>Empty</p>'}
  <h3 style="margin-top:10px">Total ${peso(tot)}</h3><input id=cn placeholder="Customer name (optional)" value="${esc(nm)}"><select id=ct><option value=dine-in ${ty==='dine-in'?'selected':''}>Dine-in</option><option value=takeout ${ty==='takeout'?'selected':''}>Takeout</option></select>
  <button class=btn style="width:100%;margin-top:6px" ${ids.length?'':'disabled'} onclick="pcharge('qrph')">Charge via QR Ph</button><button class=btn2 style="width:100%;margin-top:6px" ${ids.length?'':'disabled'} onclick="pcharge('cash')">Cash received</button><button class=btn2 style="width:100%;margin-top:6px" onclick="cart={};drawPos()">Clear</button></aside></div>`;
}
function padd(id,cat,d=1){const p=MENU.products.find(x=>x.id==id);cart[id]=(cart[id]||0)+d;if(cart[id]<=0)delete cart[id];else if(cart[id]>p.stock)cart[id]=p.stock;drawPos(cat)}
async function pcharge(m){
  try{const o=await api('/orders',{body:{source:'pos',type:$('#ct').value,name:$('#cn').value.trim()||'Walk-in',items:Object.entries(cart).map(([id,qty])=>({id:+id,qty}))}});
    const fin=async()=>{cart={};MENU=await api('/menu');showReceipt(await api('/orders/track/'+o.orderNo));drawPos()};
    if(m==='cash'){await api(`/staff/orders/${o.id}/cash`,{method:'POST',body:{}});fin()}else showQR(o.orderNo,fin);
  }catch(e){alert(e.message)}
}

/* Kitchen */
V.kitchen=async()=>{await drawK();kt=setInterval(drawK,10000)};
async function drawK(){
  const os=await api('/staff/orders?view=kitchen'),nx={pending:['preparing','Start preparing'],preparing:['ready','Mark ready'],ready:['completed','Complete']};
  if(tab!=='kitchen')return;
  $('#v').innerHTML=`<h2>Kitchen queue</h2><div class=kg>${os.map(o=>`<div class="card k-${o.status}"><h3>${esc(o.order_no)} <span class=tag>${o.status}</span></h3><p>${o.type} · ${esc(o.customer_name)}</p><ul style="margin:8px 0 12px 18px">${o.items.map(i=>`<li>${i.qty}× ${esc(i.name)}</li>`).join('')}</ul><button class=btn onclick="setS(${o.id},'${nx[o.status][0]}')">${nx[o.status][1]}</button></div>`).join('')||'<p>No active orders 🎉</p>'}</div>`;
}
async function setS(id,s){try{await api(`/staff/orders/${id}/status`,{method:'PATCH',body:{status:s}});tab==='kitchen'?drawK():V.orders()}catch(e){alert(e.message)}}

/* Orders */
V.orders=async()=>{
  const os=await api('/staff/orders?view=all');
  $('#v').innerHTML='<div class=card><h3>Recent orders</h3>'+tbl(['Order','Customer','Type','Total','Payment','Status','Actions'],os.map(o=>[esc(o.order_no),esc(o.customer_name),o.type,peso(o.total),o.payment_status+(o.payment_method?' · '+o.payment_method:''),o.status,
    o.payment_status==='unpaid'&&o.status!=='cancelled'?`<button onclick="cashPay(${o.id})">Cash received</button><button onclick="showQR('${o.order_no}',x=>{showReceipt(x);V.orders()})">Show QR</button><button onclick="setS(${o.id},'cancelled')">Cancel</button>`:o.payment_status==='paid'?`<button onclick="rcpt('${o.order_no}')">Receipt</button>`:''])).concat('</div>').join('');
}
async function cashPay(id){try{await api(`/staff/orders/${id}/cash`,{method:'POST',body:{}});V.orders()}catch(e){alert(e.message)}}

/* Products */
V.products=async()=>{
  const [m,p]=await Promise.all([api('/menu'),api('/admin/products')]);CATS=m.categories;PRODS=p;
  $('#v').innerHTML=`<div class=card><h3>Categories</h3>${CATS.map(c=>`<span class=tag>${esc(c.name)} <a onclick="delCat(${c.id})">✕</a></span> `).join('')}<div style="display:flex;gap:8px;margin-top:8px"><input id=nc placeholder="New category"><button class=btn onclick=addCat()>Add</button></div></div>
  <div class=card><h3>Products <button class=btn onclick="pform()">+ Add product</button></h3>${tbl(['Name','Category','Price','Stock','Active',''],p.map(x=>[esc(x.name),esc(CATS.find(c=>c.id===x.category_id)?.name||'—'),peso(x.price),x.stock,x.active?'Yes':'No',`<button onclick="pform(${x.id})">Edit</button>`]))}</div>`;
};
async function addCat(){try{await api('/admin/categories',{body:{name:$('#nc').value}});V.products()}catch(e){alert(e.message)}}
async function delCat(id){if(confirm('Delete category? Products stay but become uncategorized.')){await api('/admin/categories/'+id,{method:'DELETE'});V.products()}}
function pform(id){
  const p=PRODS.find(x=>x.id===id)||{name:'',description:'',price:'',stock:0,image_url:'',active:1,category_id:null};
  openModal(`<form class=left onsubmit="return false"><h3>${id?'Edit':'Add'} product</h3><input id=pn placeholder=Name value="${esc(p.name)}"><select id=pc><option value="">No category</option>${CATS.map(c=>`<option value=${c.id} ${c.id===p.category_id?'selected':''}>${esc(c.name)}</option>`).join('')}</select><input id=pp type=number step=0.01 min=0 placeholder="Price (PHP)" value="${p.price}"><input id=ps type=number min=0 placeholder=Stock value="${p.stock}"><input id=pi placeholder="Image URL (optional)" value="${esc(p.image_url)}"><input id=pd placeholder=Description value="${esc(p.description)}"><label><input id=pa type=checkbox style="width:auto" ${p.active?'checked':''}> Visible on menu</label><p><button class=btn onclick="saveP(${id||0})">Save</button></p><p id=pe class=err></p></form>`);
}
async function saveP(id){
  const b={name:$('#pn').value,category_id:$('#pc').value,price:$('#pp').value,stock:$('#ps').value,image_url:$('#pi').value,description:$('#pd').value,active:$('#pa').checked};
  try{await api(id?'/admin/products/'+id:'/admin/products',{method:id?'PUT':'POST',body:b});closeModal();V.products()}catch(e){$('#pe').textContent=e.message}
}

/* Inventory */
V.stock=async()=>{
  const p=await api('/admin/products');
  $('#v').innerHTML='<div class=card><h3>Inventory</h3><p class=err>Rows highlighted have 10 or fewer left. Stock is deducted automatically when an order is paid.</p>'+tbl(['Product','Stock','Update'],p.map(x=>[`<span class="${x.stock<=10?'low':''}">${esc(x.name)}</span>`,x.stock,`<input id=st${x.id} type=number min=0 value=${x.stock} style="width:90px;display:inline"><button onclick="setStock(${x.id})">Save</button>`])).replace('</table>','</table>')+'</div>';
}
async function setStock(id){try{await api(`/admin/products/${id}/stock`,{method:'PATCH',body:{stock:$('#st'+id).value}});V.stock()}catch(e){alert(e.message)}}

/* Users */
V.users=async()=>{
  const u=await api('/admin/users');
  $('#v').innerHTML=`<div class=card><h3>Add employee</h3><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px"><input id=un placeholder=Name><input id=ue type=email placeholder=Email><input id=up type=password placeholder="Password (8+)"><select id=ur><option>cashier</option><option>kitchen</option><option>admin</option></select><button class=btn onclick=addUser()>Create</button></div><p id=uer class=err></p></div>
  <div class=card><h3>Employees & customers</h3>${tbl(['Name','Email','Role','Status',''],u.map(x=>[esc(x.name),esc(x.email),x.role,x.active?'Active':'Disabled',x.id===me.id?'':`<button onclick="togU(${x.id},${x.active?0:1})">${x.active?'Disable':'Enable'}</button>`]))}</div>`;
};
async function addUser(){try{await api('/admin/users',{body:{name:$('#un').value,email:$('#ue').value,password:$('#up').value,role:$('#ur').value}});V.users()}catch(e){$('#uer').textContent=e.message}}
async function togU(id,a){await api('/admin/users/'+id,{method:'PATCH',body:{active:a}});V.users()}

/* Reports */
V.reports=async()=>{
  const per=$('#rp')?.value||'day';RPT=await api('/admin/reports?period='+per);
  const tot=RPT.rows.reduce((s,r)=>s+Number(r.sales),0),n=RPT.rows.reduce((s,r)=>s+r.orders,0);
  $('#v').innerHTML=`<div class=card><div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><h3 style="margin-right:auto">Sales report</h3><select id=rp style="width:auto" onchange="V.reports()"><option value=day ${per==='day'?'selected':''}>Daily (30 days)</option><option value=week ${per==='week'?'selected':''}>Weekly (12 weeks)</option><option value=month ${per==='month'?'selected':''}>Monthly (12 months)</option></select><button class=btn onclick=csv()>⬇ CSV</button><button class=btn2 onclick="window.print()">🖨 Print</button></div>
  <p class=big>${peso(tot)} <small style="font-size:14px">from ${n} paid orders</small></p>${tbl(['Period','Orders','Sales'],RPT.rows.map(r=>[esc(r.label),r.orders,peso(r.sales)]))}</div>
  <div class=card><h3>Top products</h3>${tbl(['Product','Qty','Sales'],RPT.top.map(r=>[esc(r.name),r.qty,peso(r.sales)]))}</div>
  <div class=card><h3>By payment method</h3>${tbl(['Method','Orders','Sales'],RPT.pay.map(r=>[r.method==='qrph'?'QR Ph':'Cash',r.orders,peso(r.sales)]))}</div>`;
};
function csv(){const t='Period,Orders,Sales\n'+RPT.rows.map(r=>`${r.label},${r.orders},${r.sales}`).join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([t],{type:'text/csv'}));a.download='cassey-sales.csv';a.click()}
boot();
