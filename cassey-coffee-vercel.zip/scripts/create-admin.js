// Usage: node scripts/create-admin.js "Cassey Manwa" you@email.com StrongPassword123 [admin|cashier|kitchen]
require('dotenv').config();
const mysql=require('mysql2/promise'),bcrypt=require('bcryptjs');
(async()=>{
  const [name,email,pass,role='admin']=process.argv.slice(2);
  if(!name||!email||!pass||pass.length<8||!['admin','cashier','kitchen'].includes(role)){console.log('Usage: node scripts/create-admin.js "Name" email password(8+) [admin|cashier|kitchen]');process.exit(1)}
  const db=await mysql.createConnection({host:process.env.DB_HOST,user:process.env.DB_USER,password:process.env.DB_PASS,database:process.env.DB_NAME});
  await db.query('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)',[name,email.toLowerCase(),await bcrypt.hash(pass,12),role]);
  console.log('Created',role,email);process.exit(0);
})().catch(e=>{console.error(e.message);process.exit(1)});
